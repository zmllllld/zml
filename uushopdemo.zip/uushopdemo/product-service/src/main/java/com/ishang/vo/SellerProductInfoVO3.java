package com.ishang.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

@Data
public class SellerProductInfoVO3 {
    private Boolean status;
    private Integer id;
    private String name;
    private BigDecimal price;
    private Integer stock;
    private String description;
    private String icon;
    private Map<String,Integer> category;
}
