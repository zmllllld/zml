package com.ishang.vo;

import com.ishang.entity.ProductInfo;
import lombok.Data;

import java.util.List;

@Data
public class BuyerPruductCategoryVO {

    private String name;
    private Integer type;
    private List<BuyerPruoductInfoVO> goods;

}
