package com.ishang.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SellerProductInfoVO {
    private Boolean status;
    private Integer id;
    private String name;
    private BigDecimal price;
    private Integer stock;
    private String description;
    private String icon;
    private String categoryName;
}
