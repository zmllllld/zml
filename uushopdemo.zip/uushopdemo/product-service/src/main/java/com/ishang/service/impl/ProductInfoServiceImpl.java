package com.ishang.service.impl;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ishang.entity.ProductCategory;
import com.ishang.entity.ProductInfo;
import com.ishang.exception.ShopException;
import com.ishang.mapper.ProductCategoryMapper;
import com.ishang.mapper.ProductInfoMapper;
import com.ishang.result.ResponseEnum;
import com.ishang.service.ProductInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ishang.vo.ProductExcelVO;
import com.ishang.vo.SellerProductInfoVO;
import com.ishang.vo.SellerProductInfoVO2;
import com.ishang.vo.SellerProductInfoVO3;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;

/**
 * <p>
 * 商品表 服务实现类
 * </p>
 *
 * @author zml
 * @since 2022-04-09
 */
@Service
@Slf4j
public class ProductInfoServiceImpl extends ServiceImpl<ProductInfoMapper, ProductInfo> implements ProductInfoService {

    @Autowired
    private ProductInfoMapper productInfoMapper;

    @Autowired
    private ProductCategoryMapper productCategoryMapper;
//    防止多个用户同时进行编辑
    private ReentrantLock reentrantLock = new ReentrantLock();

    @Override
    public BigDecimal findPriceById(Integer id) {
        return this.productInfoMapper.findPriceById(id);
    }

    @Transactional
    public Boolean subStockById(Integer id,Integer quantity){
//        通过id获取当前库存数量
        Integer stock = this.productInfoMapper.findsubStockById(id);
//        判断当前库存数能否小于quantity的数量,大于则正常更新库存数
        if(stock<quantity){
//            抛出异常
            throw new ShopException(ResponseEnum.STOCK_ERROR.getMsg());
        }
        reentrantLock.lock();
        Integer result = stock-quantity;
        this.productInfoMapper.updateStock(id,result);
        reentrantLock.unlock();
        return true;


    }


//    恢复库存量
    @Override
    public Boolean recoverStockById(Integer id, Integer quantity) {
//        查询出当前商品库存
        this.productInfoMapper.recoverStock(id, quantity);
        return true;
    }

    @Override
    public SellerProductInfoVO2 list(Integer page, Integer size) {
//        定义分页
        Page<ProductInfo> Infopage = new Page<>(page,size);
        Page<ProductInfo> productInfoPage = this.productInfoMapper.selectPage(Infopage, null);
        List<ProductInfo> records = productInfoPage.getRecords();
        SellerProductInfoVO2 sellerProductInfoVO2 = new SellerProductInfoVO2();
        sellerProductInfoVO2.setSize(productInfoPage.getSize());
        sellerProductInfoVO2.setTotal(productInfoPage.getTotal());
        List<SellerProductInfoVO> sellerProductInfoVOS =new ArrayList<>();
        for (ProductInfo record : records) {
            SellerProductInfoVO vo = new SellerProductInfoVO();
            vo.setId(record.getProductId());
            vo.setName(record.getProductName());
            vo.setPrice(record.getProductPrice());
            vo.setDescription(record.getProductDescription());
            vo.setIcon(record.getProductIcon());
            vo.setStock(record.getProductStock());
//           将status由数字转为true/false
            if(record.getProductStatus()== 1){
                vo.setStatus(true);
            }else{
                vo.setStatus(false);
            }
            QueryWrapper<ProductCategory> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("category_type",record.getCategoryType());
            ProductCategory productCategory = this.productCategoryMapper.selectOne(queryWrapper);
            vo.setCategoryName(productCategory.getCategoryName());
            sellerProductInfoVOS.add(vo);
        }
        sellerProductInfoVO2.setContent(sellerProductInfoVOS);
        return sellerProductInfoVO2;
    }

    @Override
    public SellerProductInfoVO2 like(String keyWord, Integer page, Integer size) {
        //        定义分页
        Page<ProductInfo> Infopage = new Page<>(page,size);
        QueryWrapper<ProductInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("product_name",keyWord);
        Page<ProductInfo> productInfoPage = this.productInfoMapper.selectPage(Infopage, queryWrapper);
        List<ProductInfo> records = productInfoPage.getRecords();
        SellerProductInfoVO2 sellerProductInfoVO2 = new SellerProductInfoVO2();
        sellerProductInfoVO2.setSize(productInfoPage.getSize());
        sellerProductInfoVO2.setTotal(productInfoPage.getTotal());
        List<SellerProductInfoVO> sellerProductInfoVOS =new ArrayList<>();
        for (ProductInfo record : records) {
            SellerProductInfoVO vo = new SellerProductInfoVO();
            vo.setId(record.getProductId());
            vo.setName(record.getProductName());
            vo.setPrice(record.getProductPrice());
            vo.setDescription(record.getProductDescription());
            vo.setIcon(record.getProductIcon());
            vo.setStock(record.getProductStock());
//           将status由数字转为true/false
            if(record.getProductStatus()== 1){
                vo.setStatus(true);
            }else{
                vo.setStatus(false);
            }
            QueryWrapper<ProductCategory> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("category_type",record.getCategoryType());
            ProductCategory productCategory = this.productCategoryMapper.selectOne(queryWrapper1);
            vo.setCategoryName(productCategory.getCategoryName());
            sellerProductInfoVOS.add(vo);
        }
        sellerProductInfoVO2.setContent(sellerProductInfoVOS);
        return sellerProductInfoVO2;

    }

    @Override
    public SellerProductInfoVO2 findByCategory(Integer categoryType, Integer page, Integer size) {
        //        定义分页
        Page<ProductInfo> Infopage = new Page<>(page,size);
        QueryWrapper<ProductInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("category_type",categoryType);
        Page<ProductInfo> productInfoPage = this.productInfoMapper.selectPage(Infopage, queryWrapper);
        List<ProductInfo> records = productInfoPage.getRecords();
        SellerProductInfoVO2 sellerProductInfoVO2 = new SellerProductInfoVO2();
        sellerProductInfoVO2.setSize(productInfoPage.getSize());
        sellerProductInfoVO2.setTotal(productInfoPage.getTotal());
        List<SellerProductInfoVO> sellerProductInfoVOS =new ArrayList<>();
        for (ProductInfo record : records) {
            SellerProductInfoVO vo = new SellerProductInfoVO();
            vo.setId(record.getProductId());
            vo.setName(record.getProductName());
            vo.setPrice(record.getProductPrice());
            vo.setDescription(record.getProductDescription());
            vo.setIcon(record.getProductIcon());
            vo.setStock(record.getProductStock());
//           将status由数字转为true/false
            if(record.getProductStatus()== 1){
                vo.setStatus(true);
            }else{
                vo.setStatus(false);
            }
            QueryWrapper<ProductCategory> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("category_type",record.getCategoryType());
            ProductCategory productCategory = this.productCategoryMapper.selectOne(queryWrapper1);
            vo.setCategoryName(productCategory.getCategoryName());
            sellerProductInfoVOS.add(vo);
        }
        sellerProductInfoVO2.setContent(sellerProductInfoVOS);
        return sellerProductInfoVO2;

    }

    public SellerProductInfoVO3 findById(Integer id){
        QueryWrapper<ProductInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("product_id",id);
        ProductInfo productInfo = this.productInfoMapper.selectOne(queryWrapper);
        SellerProductInfoVO3 vo3 = new SellerProductInfoVO3();
        vo3.setId(productInfo.getProductId());
        vo3.setName(productInfo.getProductName());
        vo3.setPrice(productInfo.getProductPrice());
        vo3.setStock(productInfo.getProductStock());
        vo3.setDescription(productInfo.getProductDescription());
        vo3.setIcon(productInfo.getProductIcon());
        if (productInfo.getProductStatus()==1){
            vo3.setStatus(true);
        }else {
            vo3.setStatus(false);
        }
        Map<String,Integer> map = new HashMap<>();
        map.put("categoryType",productInfo.getCategoryType());
        vo3.setCategory(map);
        return vo3;

    }

    @Override
    public List<ProductExcelVO> excelVOList() {
        List<ProductInfo> productInfoList = this.productInfoMapper.selectList(null);
        List<ProductExcelVO> productExcelVOList = new ArrayList<>();
        for (ProductInfo productInfo : productInfoList) {
            ProductExcelVO productExcelVO = new ProductExcelVO();
            BeanUtils.copyProperties(productInfo,productExcelVO);
            if (productInfo.getProductStatus()==1){
                productExcelVO.setProductStatus("上架");
            }else {
                productExcelVO.setProductStatus("下架");
            }
            productExcelVO.setCategoryName(this.productCategoryMapper.findCategoryNameByType(productInfo.getCategoryType()));
            productExcelVOList.add(productExcelVO);
        }
        return productExcelVOList;
    }

    @Override
    public List<ProductInfo> excelToProductInfoList(InputStream inputStream) {
        try {
            List<ProductInfo> list = new ArrayList<>();
            EasyExcel.read(inputStream)
                    .head(ProductExcelVO.class)
                    .sheet()
//                    将excel里面的数据流通过映射ProductExcelVO读取出来，生成vo对象
                    .registerReadListener(new AnalysisEventListener<ProductExcelVO>() {

                        @Override
//                        将vo对象转换为productInfo
                        public void invoke(ProductExcelVO excelData, AnalysisContext analysisContext) {
                            ProductInfo productInfo = new ProductInfo();
                            BeanUtils.copyProperties(excelData, productInfo);
                            if(excelData.getProductStatus().equals("正常")){
                                productInfo.setProductStatus(1);
                            }else{
                                productInfo.setProductStatus(0);
                            }
                            list.add(productInfo);
                        }

                        @Override
                        public void doAfterAllAnalysed(AnalysisContext analysisContext) {
                            log.info("=========================文件解析完成=========================");
                        }
                    }).doRead();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


}
