package com.ishang.service;

import com.ishang.entity.ProductInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ishang.vo.ProductExcelVO;
import com.ishang.vo.SellerProductInfoVO2;
import com.ishang.vo.SellerProductInfoVO3;
import io.swagger.models.auth.In;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 商品表 服务类
 * </p>
 *
 * @author zml
 * @since 2022-04-09
 */
public interface ProductInfoService extends IService<ProductInfo> {
    public BigDecimal findPriceById(Integer id);
    public Boolean subStockById(Integer id,Integer quantity);
    public Boolean recoverStockById(Integer id,Integer quantity);
    public SellerProductInfoVO2 list(Integer page,Integer size);
    public SellerProductInfoVO2 like(String keyWord,Integer page,Integer size);
    public SellerProductInfoVO2 findByCategory(Integer categoryType,Integer page,Integer size);
    public SellerProductInfoVO3 findById(Integer id);
    public List<ProductExcelVO> excelVOList();
    public List<ProductInfo> excelToProductInfoList(InputStream inputStream);



}
