package com.ishang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ishang.entity.ProductCategory;
import com.ishang.entity.ProductInfo;
import com.ishang.mapper.ProductCategoryMapper;
import com.ishang.mapper.ProductInfoMapper;
import com.ishang.service.ProductCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ishang.vo.BuyerPruductCategoryVO;
import com.ishang.vo.BuyerPruoductInfoVO;
import com.ishang.vo.SellerProductCategoryVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <p>
 * 类目表 服务实现类
 * </p>
 *
 * @author zml
 * @since 2022-04-09
 */
@Service
public class ProductCategoryServiceImpl extends ServiceImpl<ProductCategoryMapper, ProductCategory> implements ProductCategoryService {

    @Autowired
    ProductCategoryMapper productCategoryMapper;
    @Autowired
    ProductInfoMapper productInfoMapper;

    @Override
    @Transactional
    public List<BuyerPruductCategoryVO> buyerlist() {
//        查出所有得productCategory信息
        List<ProductCategory> productCategoryList= this.productCategoryMapper.selectList(null);
        List<BuyerPruductCategoryVO> buyerPruductCategoryVOS = new ArrayList<>();
        for (ProductCategory productCategory : productCategoryList) {
           BuyerPruductCategoryVO buyerPruductCategoryVO = new BuyerPruductCategoryVO();
           buyerPruductCategoryVO.setName(productCategory.getCategoryName());
           buyerPruductCategoryVO.setType(productCategory.getCategoryType());

//           查询出categorytype对应的具体商品
            QueryWrapper<ProductInfo> queryWrapper = new QueryWrapper();
            queryWrapper.eq("category_type",productCategory.getCategoryType());
           List<ProductInfo> productInfoList = this.productInfoMapper.selectList(queryWrapper);
//           创建一个具体商品信息的集合
            List<BuyerPruoductInfoVO> infoVOList = new ArrayList<>();
            for (ProductInfo productInfo : productInfoList) {
                BuyerPruoductInfoVO buyerPruoductInfoVO = new BuyerPruoductInfoVO();
//                BeanUtils工具类可以将属性进行对应
                BeanUtils.copyProperties(productInfo,buyerPruoductInfoVO);
//                将每个查询出来的每个商品需要的信息，以对象的形式封装在集合中
                infoVOList.add(buyerPruoductInfoVO);
            }

            buyerPruductCategoryVO.setGoods(infoVOList);
            buyerPruductCategoryVOS.add(buyerPruductCategoryVO);
        }

        return buyerPruductCategoryVOS;

    }

    @Override
    public List<SellerProductCategoryVO> SellerList() {
        List<ProductCategory> productCategoryList = this.productCategoryMapper.selectList(null);
        List<SellerProductCategoryVO> sellerProductCategoryVOS = new ArrayList<>();
        for (ProductCategory productCategory : productCategoryList) {
            SellerProductCategoryVO sellerProductCategoryVO = new SellerProductCategoryVO();
            sellerProductCategoryVO.setName(productCategory.getCategoryName());
            sellerProductCategoryVO.setType(productCategory.getCategoryType());
            sellerProductCategoryVOS.add(sellerProductCategoryVO);
        }
        return sellerProductCategoryVOS;
    }
}
