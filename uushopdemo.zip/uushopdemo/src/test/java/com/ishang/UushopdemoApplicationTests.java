package com.ishang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UushopdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
