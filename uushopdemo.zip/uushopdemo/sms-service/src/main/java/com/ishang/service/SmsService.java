package com.ishang.service;



public interface SmsService {
    public boolean send(String monbile,String code);
}
