package com.ishang.util;


import lombok.Data;
import lombok.Setter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
@Setter
@Component
@ConfigurationProperties(prefix = "jdwx")
public class SmsUtil implements InitializingBean {
//    sms将application.yml的配置信息读取到
    private String url;
    private String appkey;
    private String sign;

//    读取到的信息转为静态变量，通过类即可调用
    public static String Url;
    public static String Appkey;
    public static String Sign;


//    将读取到的配置信息赋给静态变量
    @Override
    public void afterPropertiesSet() throws Exception {
        Url = this.url;
        Appkey = this.appkey;
        Sign = this.sign;

    }
}
