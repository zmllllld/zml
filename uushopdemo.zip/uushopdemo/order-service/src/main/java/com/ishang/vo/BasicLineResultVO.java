package com.ishang.vo;

import lombok.Data;

@Data
public class BasicLineResultVO {
    private String date;
    private Integer value;
}
