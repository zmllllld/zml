package com.ishang.vo;

import com.ishang.entity.OrderMaster;
import lombok.Data;

import java.util.List;

@Data
public class SellerOrderMasterVO {
    private List<OrderMaster> content;
    private Integer size;
    private Long total;
}
