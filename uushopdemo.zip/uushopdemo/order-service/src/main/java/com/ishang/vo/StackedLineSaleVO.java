package com.ishang.vo;

import lombok.Data;

import java.util.List;

@Data
public class StackedLineSaleVO {
    private List<String> names;
    private List<String> dates;
    private List<StackedLineInnerVO> datas;

}
