package com.ishang.vo;

import lombok.Data;

@Data
public class BarResultVO {
    private String name;
    private Integer value;
}
