package com.ishang.vo;


import lombok.Data;

import java.math.BigDecimal;

@Data
public class BuyerOrderDetailVO {
    private String datailId;
    private String orderId;
    private Integer productId;
    private String productName;
    private BigDecimal productPrice;
    private Integer productQuantity;
    private String productIcon;
}
