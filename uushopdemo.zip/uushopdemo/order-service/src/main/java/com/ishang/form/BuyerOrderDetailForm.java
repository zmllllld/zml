package com.ishang.form;

import lombok.Data;

@Data
public class BuyerOrderDetailForm {
    private Integer productID;
    private Integer productQuantity;
}
