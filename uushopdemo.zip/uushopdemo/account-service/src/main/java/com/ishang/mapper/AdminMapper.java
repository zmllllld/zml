package com.ishang.mapper;

import com.ishang.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zml
 * @since 2022-04-17
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
