package com.ishang.service;

import com.ishang.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ishang.form.AdminForm;
import com.ishang.vo.AdminVO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zml
 * @since 2022-04-17
 */
public interface AdminService extends IService<Admin> {


}
