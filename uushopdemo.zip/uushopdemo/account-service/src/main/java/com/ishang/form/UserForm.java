package com.ishang.form;

import lombok.Data;

@Data
public class UserForm {
    private String code;
    private String mobile;
    private String password;
}
