package com.ishang.exception;


import com.ishang.util.ResultVOUtil;
import com.ishang.vo.ResultVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

//异常统一处理,包装成前端清楚的结果
@RestControllerAdvice
@Slf4j
public class UnifiedExceptionHandler {


//    一旦捕获到Exception.class异常，就会获得信息向前端输出
    @ExceptionHandler(value = Exception.class)
    public ResultVO handlerException(Exception e){
      log.info("服务器内部异常,{}",e.getMessage());
      return ResultVOUtil.fail(e.getMessage());
    }



}
