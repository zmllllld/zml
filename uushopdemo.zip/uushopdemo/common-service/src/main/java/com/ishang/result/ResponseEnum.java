package com.ishang.result;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ResponseEnum  {

//    枚举都大写
    STOCK_ERROR(300,"库存不足"),
    MOBILE_ERROR(301,"手机号格式错误"),
    MOBILE_EXIST(302,"手机号已注册"),
    MOBILE_IS_NULL(303,"手机号不存在"),
    PASSWORD_ERRO(304,"密码错误"),
    TOKEN_ERRO(305,"Token失效"),
    SMS_SEND_ERROR(306,"短信发送失败"),
    CODE_ERRO(307,"验证码错误"),
    USERNAME_ERRO(308,"用户名不存在");




    private Integer code;
    private String msg;
}
