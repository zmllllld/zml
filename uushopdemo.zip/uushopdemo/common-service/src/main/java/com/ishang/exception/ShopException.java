package com.ishang.exception;

public class ShopException extends RuntimeException{
    public ShopException(String message){
        super(message);
    }

}
